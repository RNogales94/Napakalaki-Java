/**
 * @author Lothar Soto Palma y Rafael Nogales Vaquero
 */
package napakalaki;

public enum CombatResult {
    WINANDWINGAME,WIN,LOSE,LOSEANDDIE,LOSEANDESCAPE,LOSEANDCONVERT;
}
